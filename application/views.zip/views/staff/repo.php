<h1>Report</h1>
<hr>
<p>Staff name : </p>
<p>Customer Name :</p>
<p>Source :</p>
<p>Shop Name :</p>
<p>Address: <addr></addr></p>
<p>Phone :</p>
<p>WhatsApp Number :</p>
<p>Used Software</p>
<p>Start Time :</p>
<p>End Time :</p>
<p>Reports :</p>
<?php 
foreach($datas->result() as $data)
{
    echo $data->shop_name;
}
?>